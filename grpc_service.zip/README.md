>>Running
    java -jar pwdhashsrvc.jar [optional port]
    You can specify a port for service to listen on. Default: 33333

    To shutdown server enter "stop" command to command line.

https://github.com/akGmit/distributedUserAccMngmtsys
